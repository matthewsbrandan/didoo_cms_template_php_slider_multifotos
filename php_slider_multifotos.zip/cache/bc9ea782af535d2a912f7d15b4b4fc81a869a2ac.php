<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BLOG FEED | CMS</title>
  <!-- Fonts -->
  <link rel="shortcut icon" href="<?php echo e(asset('favicon.png', true)); ?>" type="image/png">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/global.css', true)); ?>" rel="stylesheet"/>
  <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.min.js', true)); ?>"></script>
  <style>
    main{
      max-width: 1200px;
      min-height: 100vh;
      margin: 0 auto 3rem;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    h1{
      font-size: 3.2rem;
      margin-bottom: 0;
    }
    @media (max-width: 1440px) {
      main{ padding: 0 2rem; }
    }
    @media (max-width: 1300px) {
      main{ padding: 0 3rem; }
    }
    @media (max-width: 400px) {
      h1{ font-size: 10vw; }
    }
  </style>
</head>
<body class="antialiased">
  <main>
    <h1>404</h1>
    <p>Página não encontrada</p>
  </main>
</body>
</html><?php /**PATH C:\xampp\htdocs\codewriters\cms-themes\blog-blade\views/error-404.blade.php ENDPATH**/ ?>