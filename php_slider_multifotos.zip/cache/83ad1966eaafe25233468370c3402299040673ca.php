<section id="download_catalog">
  <img src="<?php echo e($download_catalog->image); ?>" alt="capa catalogo"/>
  <div class="content">
    <form id="form-download-catalog">
      <h2 class="titulo" style="
        <?php echo e(innerStyle('font-size', $download_catalog->title_length, null, $download_catalog->title_length . 'px')); ?>

      "
      ><?php echo e($download_catalog->title); ?></h2>
      <p class="texto" style="
        <?php echo e(innerStyle('font-size', $download_catalog->subtitle_length, null, $download_catalog->subtitle_length . 'px')); ?>

      "
      ><?php echo e($download_catalog->subtitle); ?></p>
      <div class="form-control" style="<?php echo e($download_catalog->border_color ? 'border-color: '.$download_catalog->border_color.';' : ''); ?>">
        <input type="text" name="name" id="download_catalog-name" placeholder="Nome" required/>
      </div>
      <div class="form-control" style="<?php echo e($download_catalog->border_color ? 'border-color: '.$download_catalog->border_color.';' : ''); ?>">
        <input type="email" name="email" id="download_catalog-email" placeholder="Email" required/>
      </div>
      <div class="form-control" style="<?php echo e($download_catalog->border_color ? 'border-color: '.$download_catalog->border_color.';' : ''); ?>">
        <input type="tel" name="whatsapp" id="download_catalog-whatsapp" placeholder="Whatsapp"/>
      </div>
      <button type="submit" class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($download_catalog->button->background ? 'background: '.$download_catalog->button->background.';' : ''); ?>

          <?php echo e($download_catalog->button->color ? 'color: '.$download_catalog->button->color.';' : ''); ?>

        "
      ><?php echo e($download_catalog->button->text); ?></button>
    </form>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/download_catalog.blade.php ENDPATH**/ ?>