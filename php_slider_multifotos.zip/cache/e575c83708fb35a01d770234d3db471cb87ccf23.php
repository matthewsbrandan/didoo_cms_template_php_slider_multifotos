
<?php $__env->startSection('head'); ?>
  <link href="<?php echo e(asset('css/header.css')); ?>" rel="stylesheet"/>
  <style>
    .container{
      padding: 2rem;
      max-width: 1100px;
      margin: auto;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('layout.header',[
    'header' => isset($elements['navbar']) ? $elements['navbar'] : (object) [
      'logo' => $page_config->icon
    ],
    'header_config' => (object)[
      'back_to_home' => true
    ]
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="container">
    <?php echo $elements['privacity_policy']->content; ?>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/privacy_policy.blade.php ENDPATH**/ ?>