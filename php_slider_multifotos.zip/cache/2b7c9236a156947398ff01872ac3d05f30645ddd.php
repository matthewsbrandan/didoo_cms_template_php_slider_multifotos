<header
  id="main-header"
  class="<?php echo e($header_config->class_name ?? ''); ?>"
  style="
    <?php echo e($header->background ? 'background: '.$header->background.';':''); ?>

  "
>
  <nav class="nav">
    <a href="<?php echo e(route('home')); ?>" class="logo">
      <img src="<?php echo e($header->logo); ?>"/>
    </a>
    <button
      type="button"
      class="toggle-menu"
      onclick="toggleMainMenu($(this), $(this).next())"
      style="
        <?php echo e($header->link_color ? 'color: '.$header->link_color.';': ''); ?>

      "
    ><?php echo $__env->make('utils.icons.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
    <ul
      class="horizontal-list"
      style="
        <?php echo e($header->background ? 'background: '.$header->background.' !important;':''); ?>

        <?php echo e($header->link_color ? 'color: '.$header->link_color.';': ''); ?>

      "
    >
      <?php if(isset($header_config) && $header_config->back_to_home): ?>
        <li><a href="<?php echo e(route('home')); ?>">Voltar</a></li>
      <?php else: ?>
        <?php echo $__env->make('layout.header-list',[
          'header_list_config' => (object)[
            'schedule_type' => 'button'
          ]
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
    </ul>
  </nav>
  <script>
    function toggleMainMenu(elem, target){
      if(target.hasClass('show')) elem.html(`<?php echo $__env->make('utils.icons.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`);
      else elem.html(`<?php echo $__env->make('utils.icons.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`);
      target.toggleClass('show');
      $('#main-header').toggleClass('show');
    }
    function toggleActiveMainMenu(target = null){
      $('#main-header .horizontal-list li').removeClass('active');
      if(target) target.addClass('active');
  
      if($('#main-header').hasClass('show')) $('#main-header .toggle-menu').click();
    }
  </script>
</header><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/layout/header.blade.php ENDPATH**/ ?>