<section id="service" style="
  <?php echo e(innerStyle('background-image', $service->image, null, "url('". $service->image . "')")); ?>

">
  <div class="content" id="servicos" style="
    <?php echo e(innerStyle('color', $service->text_color)); ?>

  ">
    <h2 class="titulo" style="
      <?php echo e(innerStyle('font-size', $service->title_length, null, $service->title_length . 'px')); ?>

    "><?php echo e($service->title); ?></h2>
    <p class="subtitulo subtitle" style="
      <?php echo e(innerStyle('font-size', $service->subtitle_length, null, $service->subtitle_length . 'px')); ?>

    "><?php echo e($service->subtitle); ?></p>
    <div class="container-services">
      <?php $__currentLoopData = $service->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="service">
          <img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->title); ?>"/>
          <strong style="
            <?php echo e(innerStyle('font-size', $service->item_title_length, null, $service->item_title_length . 'px')); ?>

          "><?php echo e($item->title); ?></strong>
          <p class="texto" style="
            <?php echo e(innerStyle('font-size', $service->item_description_length, null, $service->item_description_length . 'px')); ?>

          "><?php echo e($item->description); ?></p>
          <a
            href="<?php echo e($item->button->link); ?>"
            class="botao btn btn-primary btn-uppercase"
            target="_blank"
            style="
              <?php echo e($item->button->background ? 'background: '.$item->button->background.';' : ''); ?>

              <?php echo e($item->button->color ? 'color: '.$item->button->color.';' : ''); ?>

            "
          ><?php echo e($item->button->text); ?></a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <?php if(isset($service->overlay) && $service->overlay): ?>
    <div class="overlay" style="background: <?php echo e($service->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/service.blade.php ENDPATH**/ ?>