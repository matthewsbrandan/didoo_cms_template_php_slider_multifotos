<section id="section_list" style="
  <?php echo e(innerStyle('background-image', $section_list->wallpaper, null, "url('". $section_list->wallpaper . "')")); ?>

">
  <div class="content" style="background: <?php echo e($section_list->background); ?>">
    <div>
      <div>
        <h2 class="titulo" style="
          <?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>

          <?php echo e(innerStyle('font-size', $section_list->title_length, null, $section_list->title_length . 'px')); ?>

        ">
        <?php echo e($section_list->title); ?>

        </h2>
        <ul style="<?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>">
          <?php $__currentLoopData = $section_list->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <p style="
                <?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>

                <?php echo e(innerStyle('font-size', $section_list->item_length, null, $section_list->item_length . 'px')); ?>

              ">
                <?php echo e($item->item); ?>

              </p>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a
          href="<?php echo e($section_list->button->link); ?>"
          class="botao btn btn-primary btn-uppercase"
          target="_blank"
          style="
            <?php echo e($section_list->button->background ? 'background: '.$section_list->button->background.';' : ''); ?>

            <?php echo e($section_list->button->color ? 'color: '.$section_list->button->color.';' : ''); ?>

          "
        ><?php echo e($section_list->button->text); ?></a>
      </div>
    </div>
    <img src="<?php echo e($section_list->image); ?>" alt="<?php echo e($section_list->title); ?>"/>
  </div>
  <?php if(isset($section_list->overlay) && $section_list->overlay): ?>
    <div class="overlay" style="background: <?php echo e($section_list->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/section_list.blade.php ENDPATH**/ ?>