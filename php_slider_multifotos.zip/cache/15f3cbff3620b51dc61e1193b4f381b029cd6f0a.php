<div id="popup">
  <div class="overlay main-overlay">
    <div class="container">
      <section style="<?php echo e(innerStyle('background', $popup->background)); ?>">
        <div style="position: relative;">
          <img src="<?php echo e($popup->image); ?>"/>
          <div class="overlay" style="<?php echo e(innerStyle('background', $popup->overlay)); ?>"></div>
        </div>
        <div style="padding: 1rem 3rem 2rem;">
          <?php if(isset($popup->button_one)): ?>
            <a
              href="<?php echo e($popup->button_one->link); ?>"
              class="botao btn btn-primary btn-uppercase"
              style="
                <?php echo e(innerStyle('background', $popup->button_one->background)); ?>

                <?php echo e(innerStyle('color', $popup->button_one->color)); ?>

                height: 2.7rem;
                width: fit-content;
                min-width: 18rem;
                max-width: 100%;
                margin-left: auto;
                margin-right: auto;
              "
            ><?php echo e($popup->button_one->text); ?></a>
          <?php endif; ?>
          <?php if(isset($popup->button_two)): ?>
            <a
              href="<?php echo e($popup->button_two->link); ?>"
              class="botao btn btn-primary btn-uppercase"
              style="
                <?php echo e(innerStyle('background', $popup->button_two->background)); ?>

                <?php echo e(innerStyle('color', $popup->button_two->color)); ?>

                height: 2.7rem;
                width: fit-content;
                min-width: 18rem;
                max-width: 100%;
                margin-left: auto;
                margin-right: auto;
              "
            ><?php echo e($popup->button_two->text); ?></a>
          <?php endif; ?>
        </div>
      </section>
      <button
        class="closeModal"
        type="button"
        onclick="$('#popup').hide();"
        style="<?php echo e(innerStyle('color', $popup->color_button_close)); ?>"
      ><?php echo $__env->make('utils.icons.close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
    </div>
  </div>
</div>
<script>
  function showPopup(){
    $('#popup').show();
  }
  $(function(){
    $('#popup').bind('click', (e) => {
      if(e.target.classList.contains('main-overlay')){
        $('#popup').hide();
      }
    });
  });

  <?php if(in_array($popup->open_in,['start','start_end'])): ?>
    $(function(){ showPopup() });
  <?php endif; ?>
  <?php if($popup->open_in == 'after_seconds' && $popup->delay_seconds): ?>
    $(function(){
      setTimeout(function(){
        showPopup()
      }, <?php echo e($popup->delay_seconds); ?> * 1000);
    });
  <?php endif; ?>
  <?php if(in_array($popup->open_in,['end','start_end'])): ?>
    window.addEventListener("beforeunload", function(event) { 
      showPopup();
      
      let message = "Tem certeza que deseja sair dessa página?";
      event.returnValue = message; 
      return message;
    });
  <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/popup.blade.php ENDPATH**/ ?>