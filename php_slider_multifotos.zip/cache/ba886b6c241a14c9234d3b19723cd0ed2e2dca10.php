<section id="footer" style="
  <?php echo e((!isset($footer->image) || !$footer->image) && $footer->background ? 'background: '.$footer->background.'; ':''); ?>

  <?php echo e(innerStyle('background-image', $footer->image, null, "url('". $footer->image . "')")); ?>

  <?php echo e($footer->text_color ? 'color: '.$footer->text_color.'; ':''); ?>

">
  <div class="content">
    <div>
      <img src="<?php echo e($footer->logo); ?>" alt="logo" class="logo"/>
      <hr/>
      <p class="texto" style="
        <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

      "><?php echo e($footer->address); ?></p>
    </div>
    <div>
      <strong style="
        <?php echo e(innerStyle('font-size', $footer->title_length, null, $footer->title_length . 'px')); ?>

      ">ACESSO RÁPIDO</strong>
      <ul>
        <?php echo $__env->make('layout.header-list',['header_list_config' => (object)[
          'style' => innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')
        ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <li>
          <a href="<?php echo e(route('privacy.policy')); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          ">Política de Privacidade</a>
        </li>
      </ul>
    </div>
    <?php if(
      isset($footer->email) || 
      isset($footer->whatsapp) || 
      isset($footer->facebook) || 
      isset($footer->instagram) || 
      isset($footer->youtube) || 
      isset($footer->twitter)
    ): ?>
      <div id="contato">
        <strong style="
          <?php echo e(innerStyle('font-size', $footer->title_length, null, $footer->title_length . 'px')); ?>

        ">FALE CONOSCO</strong>
        <?php if(isset($footer->whatsapp)): ?>
          <a href="tel: <?php echo e($footer->whatsapp); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          "><b>Whatsapp:</b> <?php echo e($footer->whatsapp); ?></a>
        <?php endif; ?>
        <?php if(isset($footer->phone_fix)): ?>
          <a href="tel: <?php echo e($footer->phone_fix); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          "><b>Telefone:</b> <?php echo e($footer->phone_fix); ?></a>
        <?php endif; ?>
        <?php if(isset($footer->phone_cel)): ?>
          <a href="tel: <?php echo e($footer->phone_cel); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          "><b>Celular:</b> <?php echo e($footer->phone_cel); ?></a>
        <?php endif; ?>
        <?php if(isset($footer->email)): ?>
          <a href="mailto:<?php echo e($footer->email); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          "><b>Email:</b> <?php echo e($footer->email); ?></a>
        <?php endif; ?>
        <?php if(isset($footer->email_2)): ?>
          <a href="mailto:<?php echo e($footer->email_2); ?>" target="_blank" style="
            <?php echo e(innerStyle('font-size', $footer->description_length, null, $footer->description_length . 'px')); ?>

          "><b>Email 2:</b> <?php echo e($footer->email_2); ?></a>
        <?php endif; ?>
        <div class="group-icons">
          <?php if(isset($footer->facebook)): ?>
            <a href="<?php echo e($footer->facebook); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.facebook',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->instagram)): ?>
            <a href="<?php echo e($footer->instagram); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.instagram',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->youtube)): ?>
            <a href="<?php echo e($footer->youtube); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.youtube',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->twitter)): ?>
            <a href="<?php echo e($footer->twitter); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.twitter',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->tiktok)): ?>
            <a href="<?php echo e($footer->tiktok); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.tiktok',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->pinterest)): ?>
            <a href="<?php echo e($footer->pinterest); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.pinterest',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->linkedin)): ?>
            <a href="<?php echo e($footer->linkedin); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.linkedin',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->behance)): ?>
            <a href="<?php echo e($footer->behance); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.behance',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
          <?php if(isset($footer->google_business)): ?>
            <a href="<?php echo e($footer->google_business); ?>" target="_blank">
              <?php echo $__env->make('utils.icons.google_business',['icons' => (object)[
                'color' => 'currentColor'
              ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
  <a class="developed-by" href="https://didoo.com.br" target="_blank">
    <img src="<?php echo e(asset('images/done-with.png')); ?>" alt="Feito com Didoo"/>
  </a>
  <?php if(isset($footer->whatsapp)): ?>
    <!-- LINK PARA CONVERSA NO WHATSAPP -->
    <a href="https://wa.me/<?php echo e(numberWhatsappFormat($footer->whatsapp)); ?>" target="_blank" class="button-whatsapp">
      <?php echo $__env->make('utils.icons.whatsapp',['icons' => (object)[
        'color' => 'currentColor'
      ]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </a>
  <?php endif; ?>
  <?php if(isset($footer->overlay) && $footer->overlay): ?>
    <div class="overlay" style="background: <?php echo e($footer->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/footer.blade.php ENDPATH**/ ?>