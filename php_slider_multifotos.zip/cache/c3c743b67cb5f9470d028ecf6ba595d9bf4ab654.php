<section id="who_we_are" style="
  <?php echo e(innerStyle('background-image', $who_we_are->background, null, "url('". $who_we_are->background . "')")); ?>

">  
  <div class="content" id="sobre">
    <img src="<?php echo e($who_we_are->image); ?>" alt="<?php echo e($who_we_are->title); ?>"/>
    <div>
      <h2 class="titulo" style="
        <?php echo e($who_we_are->text_color ? 'color: '.$who_we_are->text_color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $who_we_are->title_length, null, $who_we_are->title_length . 'px')); ?>

      ">
       <?php echo e($who_we_are->title); ?>

      </h2>
      <p class="texto" style="
        <?php echo e($who_we_are->text_color ? 'color: '.$who_we_are->text_color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $who_we_are->description_length, null, $who_we_are->description_length . 'px')); ?>

      "><?php echo $who_we_are->description; ?></p>
      <a
        href="<?php echo e($who_we_are->button->link); ?>"
        target="_blank"
        class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($who_we_are->button->background ? 'background: '.$who_we_are->button->background.';' : ''); ?>

          <?php echo e($who_we_are->button->color ? 'color: '.$who_we_are->button->color.';' : ''); ?>

        "
      ><?php echo e($who_we_are->button->text); ?></a>
    </div>
  </div>
  <?php if(isset($who_we_are->overlay) && $who_we_are->overlay): ?>
    <div class="overlay" style="background: <?php echo e($who_we_are->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/who_we_are.blade.php ENDPATH**/ ?>