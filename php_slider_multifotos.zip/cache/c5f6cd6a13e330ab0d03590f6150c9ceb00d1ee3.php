<section id="schedule" style="
  <?php echo e(innerStyle('background-image', $schedule->image, null, "url('". $schedule->image . "')")); ?>

">
  <div class="content" id="agendar">
    <h2 class="titulo" style="
      <?php echo e(innerStyle('font-size', $schedule->title_length, null, $schedule->title_length . 'px')); ?>

      <?php echo e(innerStyle('color', $schedule->text_color)); ?>

    "><?php echo e($schedule->title); ?></h2>
    <p class="subtitulo" style="
      <?php echo e(innerStyle('font-size', $schedule->subtitle_length, null, $schedule->subtitle_length . 'px')); ?>

      <?php echo e(innerStyle('color', $schedule->text_color)); ?>

    "><?php echo e($schedule->subtitle); ?></p>
    <form id="form-schedule">
      <div class="form-control" style="margin-bottom: 1rem; <?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
        <input type="text" name="name" id="schedule-name" placeholder="Nome" required/>
      </div>
      <div class="form-grid">
        <div class="form-control" style="<?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
          <input type="email" name="email" id="schedule-email" placeholder="Email" required/>
        </div>
        <div class="form-control" style="<?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
          <input type="text" name="whatsapp" id="schedule-whatsapp" placeholder="Whatsapp" required/>
        </div>
        <div class="form-control" style="<?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
          <input type="date" name="date" id="schedule-date"/>
        </div>
        <div class="form-control" style="<?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
          <input type="time" name="time" id="schedule-time"/>
        </div>
      </div>
      <div class="form-control" style="<?php echo e($schedule->border_color ? 'border-color: '.$schedule->border_color.';' : ''); ?>">
        <textarea rows="5" name="description" id="schedule-description" placeholder="Descrição"></textarea>
      </div>
      <button type="submit" class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($schedule->button->background ? 'background: '.$schedule->button->background.';' : ''); ?>

          <?php echo e($schedule->button->color ? 'color: '.$schedule->button->color.';' : ''); ?>

        "
      >Enviar</button>
    </form>
  </div>
  <?php if(isset($schedule->overlay) && $schedule->overlay): ?>
    <div class="overlay" style="background: <?php echo e($schedule->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/schedule.blade.php ENDPATH**/ ?>