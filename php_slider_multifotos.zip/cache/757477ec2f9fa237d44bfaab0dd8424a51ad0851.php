<section id="text_divider" style="
  <?php echo e(innerStyle('background-image', $text_divider->image, null, "url('". $text_divider->image . "')")); ?>

">
  <div class="content" style="background: <?php echo e($text_divider->background); ?>">
    <h2 class="titulo"style="
      <?php echo e($text_divider->text_color ? 'color: '.$text_divider->text_color.';' : ''); ?>

      <?php echo e(innerStyle('font-size', $text_divider->title_length, null, $text_divider->title_length . 'px')); ?>

    ">
    <?php echo e($text_divider->title); ?>

    </h2>

    <p class="texto" style="
      <?php echo e($text_divider->text_color ? 'color: '.$text_divider->text_color.';' : ''); ?>

      <?php echo e(innerStyle('font-size', $text_divider->description_length, null, $text_divider->description_length . 'px')); ?>

    ">
    <?php echo e($text_divider->description); ?>

    </p>

    <a
      href="<?php echo e($text_divider->button->link); ?>"
      target="_blank"
      class="botao btn btn-primary btn-uppercase"
      style="
        <?php echo e($text_divider->button->background ? 'background: '.$text_divider->button->background.';' : ''); ?>

        <?php echo e($text_divider->button->color ? 'color: '.$text_divider->button->color.';' : ''); ?>

      "
    ><?php echo e($text_divider->button->text); ?></a>
  </div>
  <?php if(isset($text_divider->overlay) && $text_divider->overlay): ?>
    <div class="overlay" style="background: <?php echo e($text_divider->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/text_divider.blade.php ENDPATH**/ ?>