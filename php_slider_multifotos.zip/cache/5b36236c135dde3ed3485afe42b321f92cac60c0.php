<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24" height="24"
  style="fill: currentColor;"
><path d="M5 11h14v2H5z"></path></svg><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/utils/icons/minus.blade.php ENDPATH**/ ?>