
<?php $__env->startSection('head'); ?>
  <link href="<?php echo e(asset('css/header.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('css/cookies.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('css/sections/banner.css')); ?>" rel="stylesheet"/>
  <?php if(isset($elements['new_section'])): ?>
    <link href="<?php echo e(asset('css/sections/new_section.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['product_list'])): ?>
    <link href="<?php echo e(asset('css/sections/product_list.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['who_we_are'])): ?>
    <link href="<?php echo e(asset('css/sections/who_we_are.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['section_list'])): ?>
    <link href="<?php echo e(asset('css/sections/section_list.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['service'])): ?>
    <link href="<?php echo e(asset('css/sections/service.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['text_divider'])): ?>
    <link href="<?php echo e(asset('css/sections/text_divider.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(
    isset($elements['cms_catalog']) && 
    isset($elements['cms_catalog']->api_url) &&
    isset($elements['cms_catalog']->origin)
  ): ?>
    <link href="<?php echo e(asset('css/sections/cms_catalog.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['testimonial'])): ?>
    <link href="<?php echo e(asset('css/sections/testimonial.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['cms_gallery'])): ?>
    <link href="<?php echo e(asset('css/sections/cms_gallery.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['video'])): ?>
    <link href="<?php echo e(asset('css/sections/video.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['schedule'])): ?>
    <link href="<?php echo e(asset('css/sections/schedule.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['faq'])): ?>
    <link href="<?php echo e(asset('css/sections/faq.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['download_catalog'])): ?>
    <link href="<?php echo e(asset('css/sections/download_catalog.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(
    isset($elements['cms_blog']) && 
    isset($elements['cms_blog']->take)
  ): ?>
    <link href="<?php echo e(asset('css/sections/cms_blog.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <?php if(isset($elements['video_depoiments'])): ?>
    <link href="<?php echo e(asset('css/sections/video_depoiments.css')); ?>" rel="stylesheet"/>
  <?php endif; ?>
  <link href="<?php echo e(asset('css/sections/footer.css')); ?>" rel="stylesheet"/>

  <?php if(isset($elements['code']) && $elements['code']->head): ?> <?php echo $elements['code']->head; ?> <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php if(isset($elements['code']) && $elements['code']->init_body): ?> <?php echo $elements['code']->init_body; ?> <?php endif; ?>
  <?php echo $__env->make('layout.header',[
    'header' => isset($elements['navbar']) ? $elements['navbar'] : (object) [
      'logo' => $page_config->icon
    ]
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('sections.banner',[
    'banner' => $elements['banner']
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(isset($elements['new_section'])): ?>
    <?php echo $__env->make('sections.new_section',[
      'new_section' => $elements['new_section']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['product_list'])): ?>
    <?php echo $__env->make('sections.product_list',[
      'product_list' => $elements['product_list']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['who_we_are'])): ?>
    <?php echo $__env->make('sections.who_we_are',[
      'who_we_are' => $elements['who_we_are']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['section_list'])): ?>
    <?php echo $__env->make('sections.section_list',[
      'section_list' => $elements['section_list']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['service'])): ?>
    <?php echo $__env->make('sections.service',[
      'service' => $elements['service']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['text_divider'])): ?>
    <?php echo $__env->make('sections.text_divider',[
      'text_divider' => $elements['text_divider']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(
    isset($elements['cms_catalog']) && 
    isset($elements['cms_catalog']->api_url) &&
    isset($elements['cms_catalog']->origin)
  ): ?>
    <?php echo $__env->make('sections.cms_catalog',[
      'cms_catalog' => $elements['cms_catalog']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['download_catalog'])): ?>
    <?php echo $__env->make('sections.download_catalog',[
      'download_catalog' => $elements['download_catalog']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(
    isset($elements['cms_blog']) && 
    isset($elements['cms_blog']->take)
  ): ?>
    <?php echo $__env->make('sections.cms_blog',[
      'cms_blog' => $elements['cms_blog']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['testimonial'])): ?>
    <?php echo $__env->make('sections.testimonial',[
      'testimonial' => $elements['testimonial']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['video_depoiments'])): ?>
    <?php echo $__env->make('sections.video_depoiments',[
      'video_depoiments' => $elements['video_depoiments']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['cms_gallery'])): ?>
    <?php echo $__env->make('sections.cms_gallery',[
      'cms_gallery' => $elements['cms_gallery']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['video'])): ?>
    <?php echo $__env->make('sections.video',[
      'video' => $elements['video']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['schedule'])): ?>
    <?php echo $__env->make('sections.schedule',[
      'schedule' => $elements['schedule']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if(isset($elements['faq'])): ?>
    <?php echo $__env->make('sections.faq',[
      'faq' => $elements['faq']
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php echo $__env->make('sections.footer',[
    'footer' => $elements['footer']
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <?php echo $__env->make('layout.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if(isset($elements['jivochat']) && $elements['jivochat']->widget): ?>
    <script src="//code-sa1.jivosite.com/widget/<?php echo e($elements['jivochat']->widget); ?>" async></script>
  <?php endif; ?>
  <script>
    const icons = {
      minus: `<?php echo $__env->make('utils.icons.minus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`,
      plus: `<?php echo $__env->make('utils.icons.plus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`
    }
    function toggleIconPlusMinus(target){0
      if(target.hasClass('icon-minus')) target.html(icons.plus);
      else target.html(icons.minus);
      target.toggleClass('icon-minus icon-plus');
    }
    function handleScrollNextOrPrevItem(next, id, widthContent){
      let container = getById(id);
      let maxWidth = container.scrollWidth;

      let newPositionScroll = 0;
      if(next){
        newPositionScroll = container.scrollLeft + widthContent;
      
        if(newPositionScroll > maxWidth) container.scrollLeft = maxWidth;
        else container.scrollLeft = newPositionScroll;
      }else{
        newPositionScroll = container.scrollLeft - widthContent;
      
        if(newPositionScroll < 0) container.scrollLeft = 0;
        else container.scrollLeft = newPositionScroll;
      }
    }
  </script>
  <?php if(
    isset($elements['cms_catalog']) && 
    isset($elements['cms_catalog']->api_url) &&
    isset($elements['cms_catalog']->origin)
  ): ?>
    <script>
      // INTIALIZATION
      const cms_catalog = {
        api_url: `<?php echo e($elements['cms_catalog']->api_url); ?>`,
        take: `<?php echo e($elements['cms_catalog']->take); ?>`,
        token: `<?php echo e($elements['cms_catalog']->token); ?>`,
        origin: `<?php echo e($elements['cms_catalog']->origin); ?>`
      };
    </script>
    <script src="<?php echo e(asset('js/cms_catalog.js')); ?>"></script>
  <?php endif; ?>
  <?php if(
    isset($elements['cms_blog']) &&
    isset($elements['cms_blog']->take)
  ): ?>
    <script>
      // INITIALIZATION
      const cms_blog = {
        url: `<?php echo e(route('blog.feed.more')); ?>`,
        take: `<?php echo e($elements['cms_blog']->take); ?>`,
        token: `<?php echo e($cms_page_token); ?>`,
        show: `<?php echo route('blog.feed.show',['slug' => '']); ?>`
      };
    </script>
    <script src="<?php echo e(asset('js/cms_blog.js')); ?>"></script>
    <!-- post/feed/more -->
  <?php endif; ?>
  <?php if(
    isset($elements['cms_gallery']) &&
    isset($elements['cms_gallery']->slug)
  ): ?>
    <script>
      // INTIALIZATION
      const cms_gallery = {
        slug: `<?php echo e($elements['cms_gallery']->slug); ?>`,
        token: `<?php echo e($cms_page_token); ?>`,
        take: <?php echo $elements['cms_gallery']->take ?? 'null'; ?>,
        url: `<?php echo e(route('api.gallery.show',['slug' => $elements['cms_gallery']->slug])); ?>`
      };
    </script>
    <script src="<?php echo e(asset('js/cms_gallery.js')); ?>"></script>
  <?php endif; ?>
  <?php if(isset($elements['schedule'])): ?>
    <script>
      // INITIALIZATION
      const schedule = {
        whatsapp: <?php echo isset($elements['footer']) && $elements['footer']->whatsapp ? $elements['footer']->whatsapp : 'null'; ?>,
        page_id: `<?php echo e($page_config->page_id); ?>`,
        page_owner_id: `<?php echo e($page_config->user_id); ?>`,
        url: `<?php echo e(route('api.contact.send')); ?>`,
        token: `<?php echo e($cms_page_token); ?>`,
      };
    </script>
    <script src="<?php echo e(asset('js/schedule.js')); ?>"></script>
  <?php endif; ?>
  <?php if(
    isset($elements['download_catalog']) &&
    isset($elements['download_catalog']->pdf_url)
  ): ?>
    <script>
      // INITIALIZATION
      const download_catalog = {
        page_id: `<?php echo e($page_config->page_id); ?>`,
        page_owner_id: `<?php echo e($page_config->user_id); ?>`,
        url: `<?php echo e(route('api.contact.send')); ?>`,
        token: `<?php echo e($cms_page_token); ?>`,
        pdf_catalog_url: `<?php echo e($elements['download_catalog']->pdf_url); ?>`
      };
    </script>
    <script src="<?php echo e(asset('js/download_catalog.js')); ?>"></script>
  <?php endif; ?>
  <?php if(isset($elements['code']) && $elements['code']->final_body): ?> <?php echo $elements['code']->final_body; ?> <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/index.blade.php ENDPATH**/ ?>