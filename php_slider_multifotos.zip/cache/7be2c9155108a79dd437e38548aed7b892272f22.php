<section id="multi_photo" style="
  <?php echo e(innerStyle('background-image', $multi_photos->image, null, "url('". $multi_photos->image . "')")); ?>

">
  <div class="content" id="multi-fotos">
    <div class="wrapper">
      <h2 class="titulo" style="
        <?php echo e(innerStyle('font-size', $multi_photos->title->length, null, $multi_photos->title->length . 'px')); ?>

        <?php echo e(innerStyle('color', $multi_photos->title->color)); ?>

      ">
        <?php echo e($multi_photos->title->text); ?>

        <button
          type="button"
          class="btn-search"
          onclick="callSearchBoxMultiPhotos()"
        ><?php echo $__env->make('utils.icons.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
      </h2>
      <p class="subtitulo subtitle" style="
        <?php echo e(innerStyle('font-size', $multi_photos->subtitle->length, null, $multi_photos->subtitle->length . 'px')); ?>

        <?php echo e(innerStyle('color', $multi_photos->subtitle->color)); ?>

      "><?php echo e($multi_photos->subtitle->text); ?></p>
    </div>
    <div class="overflow">
      <div class="container-multi_photos wrapper">
        <?php $__currentLoopData = $multi_photos->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div
            class="multi_photo"
            data-slug="<?php echo e($item->slug); ?>"
            data-title="<?php echo e($item->title); ?>"
            data-description="<?php echo e($item->description); ?>"
          >
            <?php if(isset($item->video) && $item->video): ?>
              <div class="container-video">
                <iframe
                  src="<?php echo e($item->video); ?>"
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen=""
                ></iframe>
              </div>
            <?php else: ?> <img src="<?php echo e($item->images[0]->src ?? asset('no-image.jpg')); ?>" alt="<?php echo e($item->title); ?>"/> <?php endif; ?>
            <a
              href="<?php echo e(isset($item->slug) && $item->slug ? route('product.show',['slug' => $item->slug]) : 'javascript:;'); ?>"
              <?php if(isset($item->slug) && $item->slug): ?> target="_blank" <?php endif; ?>
            >
              <strong style="
                <?php echo e(innerStyle('font-size', $multi_photos->service_title->length, null, $multi_photos->service_title->length . 'px')); ?>

                <?php echo e(innerStyle('color', $multi_photos->service_title->color)); ?>

              "><?php echo e($item->title); ?></strong>
            </a>
            <p class="texto" style="
              <?php echo e(innerStyle('font-size', $multi_photos->service_description->length, null, $multi_photos->service_description->length . 'px')); ?>

              <?php echo e(innerStyle('color', $multi_photos->service_description->color)); ?>

            "><?php echo e($item->description); ?></p>
            <a
              href="javascript:;"
              class="botao btn btn-primary btn-uppercase"
              style="
                <?php echo e($multi_photos->button_see_more->background ? 'background: '.$multi_photos->button_see_more->background.';' : ''); ?>

                <?php echo e($multi_photos->button_see_more->color ? 'color: '.$multi_photos->button_see_more->color.';' : ''); ?>

              "
              onclick='handleShowMultiPhotos(<?php echo json_encode($item); ?>)'
            ><?php echo e($multi_photos->button_see_more->text ?? 'Ver Mais'); ?></a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <?php if(isset($multi_photos->overlay) && $multi_photos->overlay): ?>
    <div class="overlay" style="background: <?php echo e($multi_photos->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/multi_photos.blade.php ENDPATH**/ ?>