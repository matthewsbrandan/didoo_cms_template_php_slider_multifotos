<?php
  if(!isset($page_config)) $page_config = (object)[
    'icon' => asset('favicon.png', true),
    'title' => 'Erro 404'
  ];
?>

<?php $__env->startSection('head'); ?>
  <style>
    main{
      max-width: 1200px;
      min-height: calc(100vh - 3rem);
      margin: 0 auto 3rem;
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    h1{
      font-size: 3.2rem;
      margin-bottom: 0;
    }
    @media (max-width: 1440px) {
      main{ padding: 0 2rem; }
    }
    @media (max-width: 1300px) {
      main{ padding: 0 3rem; }
    }
    @media (max-width: 400px) {
      h1{ font-size: 10vw; }
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <h1>404</h1>
  <p>Página não encontrada</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/error-404.blade.php ENDPATH**/ ?>