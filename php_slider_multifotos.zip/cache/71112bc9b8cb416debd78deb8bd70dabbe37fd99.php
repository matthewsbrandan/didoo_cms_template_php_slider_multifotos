<section id="banner">
  <div class="carousel">
    <?php $__currentLoopData = $banner->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="carousel-item" style="background-image: url('<?php echo e($image->src); ?>');">
        <div class="content">
          <div>
            <h1 class="titulo" style="
              <?php echo e($image->title->color ? 'color: '.$image->title->color.';' : ''); ?>

              <?php echo e(innerStyle('font-size', $banner->title_length, null, $banner->title_length . 'px')); ?>

            "><?php echo e($image->title->text); ?></h1>
            <p class="texto description" style="
              <?php echo e($image->description->color ? 'color: '.$image->description->color.';' : ''); ?>

              <?php echo e(innerStyle('font-size', $banner->description_length, null, $banner->description_length . 'px')); ?>

            "><?php echo $image->description->text; ?></p>
            <?php if(isset($image->button)): ?>
              <a
                class="botao btn btn-primary btn-uppercase"
                href="<?php echo e($image->button->link); ?>"
                style="
                  align-self: center;
                  <?php echo e(innerStyle('background', $image->button->background)); ?>

                  <?php echo e(innerStyle('color', $image->button->color)); ?>

                "
              ><?php echo e($image->button->text); ?></a>
            <?php endif; ?>
          </div>
        </div>
        <div class="overlay" style="background: <?php echo e($image->overlay); ?>"></div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/banner/carousel.blade.php ENDPATH**/ ?>