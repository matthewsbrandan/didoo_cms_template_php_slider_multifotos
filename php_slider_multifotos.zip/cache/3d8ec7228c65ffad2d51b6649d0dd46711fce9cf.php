<?php echo $__env->make('sections.banner.' . $banner_variations->model->model_type,[
  'banner' => $banner_variations->model->$variation
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider_multifotos\views/sections/banner/index.blade.php ENDPATH**/ ?>