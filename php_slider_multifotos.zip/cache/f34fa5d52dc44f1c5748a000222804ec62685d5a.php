
<?php $__env->startSection('head'); ?>
  <link href="<?php echo e(asset('css/header.css')); ?>" rel="stylesheet"/>
  <style>
    main{ overflow: hidden; }
    .container{
      padding: 2rem;
      overflow: auto;
      position: relative;
      background-size: cover;
      background-position-x: center;
      height: 100vh;
      width: 100vw;
    }
    .content{
      max-width: 800px;
      margin: auto;
    }
    .image {
      border-radius: .6rem;
      object-fit: cover;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <div class="container" style="
    <?php echo e(innerStyle('background-image', $links->background, null, "url('". $links->background . "')")); ?>

  ">
    <div class="content" style="z-index: 1; position: relative;">
      <img src="<?php echo e($links->logo); ?>" class="image" alt="logo" style="
        width: 10rem;
        margin: auto auto .4rem;
        display: block;
      "/>
      <?php $__currentLoopData = $links->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($link->link); ?>" target="_blank">
          <img src="<?php echo e($link->image); ?>" class="image" alt="link" style="
            width: 100%;
            height: 15rem;
            margin: .4rem 0;
          "/>
        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="overlay" style="background: <?php echo e($links->overlay); ?>;"></div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/links.blade.php ENDPATH**/ ?>