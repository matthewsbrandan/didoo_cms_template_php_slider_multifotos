<section
  style="background-image: url('<?php echo e($banner->image); ?>')"
  id="banner"
>
  <div class="content">
    <div>
      <?php if($banner->hero): ?>
        <img src="<?php echo e($banner->hero); ?>" alt="hero"/>
      <?php endif; ?>
    </div>
    <div>
      <hgroup>
        <h1 class="titulo" style="
          <?php echo e($banner->title->color ? 'color: '.$banner->title->color.';' : ''); ?>

        "><?php echo e($banner->title->text); ?></h1>
        <strong class="subtitulo" style="
          <?php echo e($banner->caption->color ? 'color: '.$banner->caption->color.';' : ''); ?>

        "><?php echo e($banner->caption->text); ?></strong>
      </hgroup>
      <p class="texto description" style="
        <?php echo e($banner->description->color ? 'color: '.$banner->description->color.';' : ''); ?>

      "><?php echo $banner->description->text; ?></p>
      <a
        class="botao btn btn-primary btn-uppercase"
        href="<?php echo e($banner->button->link); ?>"
        style="
          <?php echo e($banner->button->background ? 'background: '.$banner->button->background.';' : ''); ?>

          <?php echo e($banner->button->color ? 'color: '.$banner->button->color.';' : ''); ?>

        "
      ><?php echo e($banner->button->text); ?></a>
    </div>
  </div>
  <div class="overlay" style="background: <?php echo e($banner->overlay); ?>"></div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/banner.blade.php ENDPATH**/ ?>