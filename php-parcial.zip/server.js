const open = require('open');
open('http://localhost/codewriters/templates_didoo/php',{ app: { name: 'edge'} });