const chromeLauncher = require('chrome-launcher');

chromeLauncher.launch({
  startingUrl: 'http://localhost/codewriters/templates_didoo/php'
}).finally(() => { process.exit(); });