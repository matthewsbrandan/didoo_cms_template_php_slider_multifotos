<section id="service">
  <div class="content" id="servicos">
    <h2><?php echo e($service->title); ?></h2>
    <p class="subtitle"><?php echo e($service->subtitle); ?></p>
    <div class="container-services">
      <?php $__currentLoopData = $service->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="service">
          <img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->title); ?>"/>
          <strong><?php echo e($item->title); ?></strong>
          <p><?php echo e($item->description); ?></p>
          <a
            href="<?php echo e($item->button->link); ?>"
            class="btn btn-primary btn-uppercase"
            target="_blank"
            style="
              <?php echo e($item->button->background ? 'background: '.$item->button->background.';' : ''); ?>

              <?php echo e($item->button->color ? 'color: '.$item->button->color.';' : ''); ?>

            "
          ><?php echo e($item->button->text); ?></a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/service.blade.php ENDPATH**/ ?>