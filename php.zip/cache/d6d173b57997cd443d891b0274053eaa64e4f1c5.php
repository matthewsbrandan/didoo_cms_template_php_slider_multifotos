<section id="cms_gallery"
  style="<?php echo e(innerStyle('background', $cms_gallery->background)); ?>"
>
  <div class="content" id="galeria" style="
    <?php echo e(innerStyle('color', $cms_gallery->text_color)); ?>

  ">
    <h2><?php echo e($cms_gallery->title); ?></h2>
    <p><?php echo e($cms_gallery->subtitle); ?></p>
    <div id="container-gallery">
      <p class="text-loading texto">Carregando Galeria...</p>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/cms_gallery.blade.php ENDPATH**/ ?>