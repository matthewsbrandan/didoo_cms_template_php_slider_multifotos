<section 
  id="video"
  style="<?php echo e(innerStyle('background-image', $video->wallpaper, null, "url('".$video->wallpaper."')")); ?>"
>
  <button type="button" class="btn" onclick="$(this).hide('slow').next().attr('src','<?php echo e($video->src); ?>').show('slow');">
    <img src="<?php echo e(asset('images/seta2.png')); ?>" alt="play"/>
  </button>
  <iframe
    src=""
    style="display: none;"
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen=""
  ></iframe>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/video.blade.php ENDPATH**/ ?>