<section
  style="background-image: url('<?php echo e($banner->image); ?>')"
  id="banner"
>
  <div class="content">
    <hgroup>
      <h1 class="titulo" style="
        <?php echo e($banner->title->color ? 'color: '.$banner->title->color.';' : ''); ?>

      "><?php echo e($banner->title->text); ?></h1>
      <strong class="subtitulo" style="
        <?php echo e($banner->caption->color ? 'color: '.$banner->caption->color.';' : ''); ?>

      "><?php echo e($banner->caption->text); ?></strong>
    </hgroup>
    <p class="texto description" style="
      <?php echo e($banner->description->color ? 'color: '.$banner->description->color.';' : ''); ?>

    "><?php echo $banner->description->text; ?></p>
    <button
      class="botao btn btn-primary btn-uppercase"
      style="
        <?php echo e($banner->button->background ? 'background: '.$banner->button->background.';' : ''); ?>

        <?php echo e($banner->button->color ? 'color: '.$banner->button->color.';' : ''); ?>

      "
    ><?php echo e($banner->button->text); ?></button>
  </div>
  <div class="overlay" style="background: <?php echo e($banner->overlay); ?>"></div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/banner.blade.php ENDPATH**/ ?>