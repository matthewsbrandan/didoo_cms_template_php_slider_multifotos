<section id="cms_catalog">
  <div class="content" id="produtos">
    <h2
      style="<?php echo e($cms_catalog->text_color ? 'color: '.$cms_catalog->text_color.';' : ''); ?>"
    ><?php echo e($cms_catalog->title); ?></h2>
    <style>
      #container-products strong, #container-products .text-loading{
        <?php echo e($cms_catalog->text_color ? 'color: '.$cms_catalog->text_color.';' : ''); ?>

      }
      #container-products .price{
        <?php echo e($cms_catalog->highlight_color ? 'color: '.$cms_catalog->highlight_color.';' : ''); ?>

      }
    </style>
    
    <div id="container-products">
      <p class="text-loading">Carregando Produtos...</p>
    </div>

    <a
      href="<?php echo e($cms_catalog->button->link); ?>"
      target="_blank"
      class="btn btn-primary btn-uppercase"
      style="
        <?php echo e($cms_catalog->button->background ? 'background: '.$cms_catalog->button->background.';' : ''); ?>

        <?php echo e($cms_catalog->button->color ? 'color: '.$cms_catalog->button->color.';' : ''); ?>

      "
    ><?php echo e($cms_catalog->button->text); ?></a>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/cms_catalog.blade.php ENDPATH**/ ?>