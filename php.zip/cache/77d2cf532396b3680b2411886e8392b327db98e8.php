
  <link href="<?php echo e(asset('assets/css/global.css', true)); ?>" rel="stylesheet"/>
  <style>
    main{
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      width: 100vw;

      background: var(--primary-500);
    }
    img{
      width: 8rem;
      height: 8rem;
      object-fit: cover;
    }
    p{
      text-align: center;
      color: var(--gray-50);
    }
  </style>
<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <img src="<?php echo e(asset('favicon.png', true)); ?>" alt="Logo"/>
  <p>Conheça o nosso CMS e crie seu site.</p>
  <a href="<?php echo e($cms_url); ?>" class="btn btn-gray" target="_blank">
    Crie seu site
  </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/welcome.blade.php ENDPATH**/ ?>