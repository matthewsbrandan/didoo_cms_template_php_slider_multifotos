<section id="text_divider">
  <div class="content" style="background: <?php echo e($text_divider->background); ?>">
    <h2 style="<?php echo e($text_divider->text_color ? 'color: '.$text_divider->text_color.';' : ''); ?>">
    <?php echo e($text_divider->title); ?>

    </h2>

    <p style="<?php echo e($text_divider->text_color ? 'color: '.$text_divider->text_color.';' : ''); ?>">
    <?php echo e($text_divider->description); ?>

    </p>

    <a
      href="<?php echo e($text_divider->button->link); ?>"
      target="_blank"
      class="btn btn-primary btn-uppercase"
      style="
        <?php echo e($text_divider->button->background ? 'background: '.$text_divider->button->background.';' : ''); ?>

        <?php echo e($text_divider->button->color ? 'color: '.$text_divider->button->color.';' : ''); ?>

      "
    ><?php echo e($text_divider->button->text); ?></a>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/text_divider.blade.php ENDPATH**/ ?>