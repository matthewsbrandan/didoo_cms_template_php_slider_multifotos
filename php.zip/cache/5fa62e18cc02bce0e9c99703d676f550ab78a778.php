<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($page_config->title ?? 'CMS'); ?></title>
  <!-- Fonts -->
  <link rel="shortcut icon" href="<?php echo e($page_config->icon ?? asset('favicon.png', true)); ?>" type="image/png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <meta name="description" content="<?php echo e($page_config->metadescription ?? ''); ?>">

  <?php if(isset($page_config) && isset($page_config->fonts)): ?> <?php echo $page_config->fonts; ?> <?php endif; ?>
  
  <link href="<?php echo e(asset('css/global.css')); ?>" rel="stylesheet"/>

  <?php echo $__env->yieldContent('head'); ?>

  <?php if(isset($page_config) && isset($page_config->css)): ?>
    <style> <?php echo $page_config->css; ?></style>
  <?php endif; ?>
</head>
<body class="antialiased">
  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <script>
    function getById(id){ return document.getElementById(id); }
  </script>
  <?php echo $__env->make('utils.modalMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/layout/app.blade.php ENDPATH**/ ?>