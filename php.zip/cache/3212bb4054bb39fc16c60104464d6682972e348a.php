<section id="new_section">
  <div class="content">
    <h2 style="
      <?php echo e($new_section->text_color ? 'color: '.$new_section->text_color.';' : ''); ?>

    "><?php echo e($new_section->title); ?></h2>
    <p class="description" style="
      <?php echo e($new_section->text_color ? 'color: '.$new_section->text_color.';' : ''); ?>

    "><?php echo $new_section->description; ?></p>
    <a
      href="<?php echo e($new_section->button->link); ?>"
      target="_blank"
      class="btn btn-primary btn-uppercase"
      style="
        <?php echo e($new_section->button->background ? 'background: '.$new_section->button->background.';' : ''); ?>

        <?php echo e($new_section->button->color ? 'color: '.$new_section->button->color.';' : ''); ?>

      "
    ><?php echo e($new_section->button->text); ?></a>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/new_section.blade.php ENDPATH**/ ?>