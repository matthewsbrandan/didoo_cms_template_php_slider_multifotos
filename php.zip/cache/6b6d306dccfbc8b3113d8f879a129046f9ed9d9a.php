<section id="faq">
  <div class="content" style="background: <?php echo e($faq->background); ?>">
    <h2 style="<?php echo e($faq->text_color ? 'color: '.$faq->text_color.';' : ''); ?>">
      <?php echo e($faq->title); ?>

    </h2>
    <style>
      .icon-toggler{
        <?php echo e(innerStyle('color',$faq->answer_color)); ?>

      }
    </style>
    <ul>
      <?php $__currentLoopData = $faq->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
          <strong 
            onclick="$(this).next().toggle('slow'); toggleIconPlusMinus($(this).children('.icon-toggler'))"
            style="<?php echo e($faq->text_color ? 'color: '.$faq->text_color.';' : ''); ?>"
          >
            <?php if($i === 0): ?>
              <span class="icon-toggler icon-minus"><?php echo $__env->make('utils.icons.minus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
            <?php else: ?>
              <span class="icon-toggler icon-plus"><?php echo $__env->make('utils.icons.plus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
            <?php endif; ?>
            <?php echo e($question->title); ?>

          </strong>
          <p style="
            <?php echo e($i > 0 ? 'display: none; ':''); ?>

            <?php echo e($faq->answer_color ? 'color: '.$faq->answer_color.';' : ''); ?>

          "><?php echo e($question->description); ?></p>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/faq.blade.php ENDPATH**/ ?>