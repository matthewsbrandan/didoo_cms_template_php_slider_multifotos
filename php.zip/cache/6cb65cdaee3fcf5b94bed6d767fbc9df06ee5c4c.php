<section id="video_depoiments">
  <div class="content">
    <h2><?php echo e($video_depoiments->title); ?></h2>
    <p><?php echo e($video_depoiments->substitle); ?></p>
    <div class="container-depoiments">
      <?php $__currentLoopData = $video_depoiments->depoiments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depoiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!in_array($depoiment->link,['#',''])): ?>
          <div
            class="container-depoiment-item"
            style="<?php echo e(innerStyle('background-image', $depoiment->wallpaper, null, "url('".$depoiment->wallpaper."')")); ?>"
          >
            <button type="button" class="btn" onclick="$(this).hide('slow').next().attr('src','<?php echo e($depoiment->link); ?>').show('slow');">
              <img src="<?php echo e(asset('images/seta2.png')); ?>" alt="play"/>
            </button>
            <iframe
              src=""
              style="display: none;"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen=""
            ></iframe>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a
      href="<?php echo e($video_depoiments->button->link); ?>"
      target="_blank"
      class="btn btn-primary btn-uppercase"
      style="
        <?php echo e($video_depoiments->button->background ? 'background: '.$video_depoiments->button->background.';' : ''); ?>

        <?php echo e($video_depoiments->button->color ? 'color: '.$video_depoiments->button->color.';' : ''); ?>

      "
    ><?php echo e($video_depoiments->button->text); ?></a>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/video_depoiments.blade.php ENDPATH**/ ?>