# TEMPLATE PADRAO PHP

[LINK-LOCAL](http://localhost/codewriters/templates_didoo/php)