<section id="banner" style="
  <?php echo e(innerStyle('background-image', $banner->image, null, "url('". $banner->image . "')")); ?>

">
  <div class="content">
    <div>
      <strong class="subtitulo" style="
        <?php echo e($banner->title->color ? 'color: '.$banner->title->color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $banner->title->length, null, $banner->title->length . 'px')); ?>

      "><?php echo e($banner->title->text); ?></strong>
      <h1 class="titulo" style="
        <?php echo e($banner->title_highlight->color ? 'color: '.$banner->title_highlight->color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $banner->title_highlight->length, null, $banner->title_highlight->length . 'px')); ?>

      "><?php echo e($banner->title_highlight->text); ?></h1>
      <p class="texto description" style="
        <?php echo e($banner->description_1->color ? 'color: '.$banner->description_1->color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $banner->description_1->length, null, $banner->description_1->length . 'px')); ?>

      "><?php echo $banner->description_1->text; ?></p>
      <iframe
        src="<?php echo e($banner->video); ?>"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen=""
      ></iframe>
      <p class="texto description" style="
        <?php echo e($banner->description_2->color ? 'color: '.$banner->description_2->color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $banner->description_2->length, null, $banner->description_2->length . 'px')); ?>

      "><?php echo $banner->description_2->text; ?></p>
      <a
        class="botao btn btn-primary btn-uppercase"
        href="<?php echo e($banner->button->link); ?>"
        style="
          <?php echo e($banner->button->background ? 'background: '.$banner->button->background.';' : ''); ?>

          <?php echo e($banner->button->color ? 'color: '.$banner->button->color.';' : ''); ?>

        "
      ><?php echo e($banner->button->text); ?></a>
    </div>
  </div>
  <div class="overlay" style="background: <?php echo e($banner->overlay); ?>"></div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/banner/text_video.blade.php ENDPATH**/ ?>