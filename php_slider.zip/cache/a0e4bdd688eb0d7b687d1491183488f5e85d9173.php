<section id="banner">
  <div class="content">
    <div>
      <hgroup>
        <h1 class="titulo" style="
          <?php echo e($banner->title->color ? 'color: '.$banner->title->color.';' : ''); ?>

        "><?php echo e($banner->title->text); ?></h1>
        <strong class="subtitulo" style="
          <?php echo e($banner->caption->color ? 'color: '.$banner->caption->color.';' : ''); ?>

        "><?php echo e($banner->caption->text); ?></strong>
      </hgroup>
      <p class="texto description" style="
        <?php echo e($banner->description->color ? 'color: '.$banner->description->color.';' : ''); ?>

      "><?php echo $banner->description->text; ?></p>
      <a
        class="botao btn btn-primary btn-uppercase"
        href="<?php echo e($banner->button->link); ?>"
        style="
          <?php echo e($banner->button->background ? 'background: '.$banner->button->background.';' : ''); ?>

          <?php echo e($banner->button->color ? 'color: '.$banner->button->color.';' : ''); ?>

        "
      ><?php echo e($banner->button->text); ?></a>
    </div>
  </div>
  <iframe
    src="<?php echo e($banner->video); ?>?autoplay=1&mute=1&loop=1&controls=0"
    class="bg-video"
    style="
      width: 100%;
      height: 100%;
    "
    frameborder="0"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowfullscreen=""
  ></iframe>
  <div class="overlay" style="background: <?php echo e($banner->overlay); ?>"></div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/banner/text_video.blade.php ENDPATH**/ ?>