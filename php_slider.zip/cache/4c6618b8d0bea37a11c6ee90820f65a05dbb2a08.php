<section id="product_list" style="
  <?php echo e(isset($product_list->image) && $product_list->image ? '' : 'background: ' . $product_list->background . ';'); ?>

  <?php echo e(innerStyle('background-image', $product_list->image, null, "url('". $product_list->image . "')")); ?>

">
  <div class="content">
    <div class="container-items">
      <?php $__currentLoopData = $product_list->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
          <img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->title); ?>"/>
          <strong style="<?php echo e($product_list->text_color ? 'color: '.$product_list->text_color.';' : ''); ?>"><?php echo e($item->title); ?></strong>
          <p class="texto" style="<?php echo e($product_list->text_color ? 'color: '.$product_list->text_color.';' : ''); ?>"><?php echo e($item->description); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="group-buttons">
      <a
        href="<?php echo e($product_list->button->link); ?>"
        target="_blank"
        class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($product_list->button->background ? 'background: '.$product_list->button->background.';' : ''); ?>

          <?php echo e($product_list->button->color ? 'color: '.$product_list->button->color.';' : ''); ?>

        "
      ><?php echo e($product_list->button->text); ?></a>
    </div>
  </div>
  <?php if(isset($product_list->overlay) && $product_list->overlay): ?>
    <div class="overlay" style="background: <?php echo e($product_list->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/product_list.blade.php ENDPATH**/ ?>