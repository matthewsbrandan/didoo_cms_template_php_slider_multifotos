<section id="new_section" style="
  <?php echo e(innerStyle('background-image', $new_section->image, null, "url('". $new_section->image . "')")); ?>

">
  <div class="content">
    <h2 class="titulo" style="
      <?php echo e($new_section->text_color ? 'color: '.$new_section->text_color.';' : ''); ?>

      <?php echo e(innerStyle('font-size', $new_section->title_length, null, $new_section->title_length . 'px')); ?>

    "><?php echo e($new_section->title); ?></h2>
    <p class="description texto" style="
      <?php echo e($new_section->text_color ? 'color: '.$new_section->text_color.';' : ''); ?>

      <?php echo e(innerStyle('font-size', $new_section->description_length, null, $new_section->description_length . 'px')); ?>

    "><?php echo $new_section->description; ?></p>
    <a
      href="<?php echo e($new_section->button->link); ?>"
      target="_blank"
      class="botao btn btn-primary btn-uppercase"
      style="
        <?php echo e($new_section->button->background ? 'background: '.$new_section->button->background.';' : ''); ?>

        <?php echo e($new_section->button->color ? 'color: '.$new_section->button->color.';' : ''); ?>

      "
    ><?php echo e($new_section->button->text); ?></a>
  </div>
  <?php if(isset($new_section->overlay) && $new_section->overlay): ?>
    <div class="overlay" style="background: <?php echo e($new_section->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/new_section.blade.php ENDPATH**/ ?>