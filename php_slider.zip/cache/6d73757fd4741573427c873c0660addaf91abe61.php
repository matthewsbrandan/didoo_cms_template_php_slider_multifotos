<section id="video_depoiments" style="
  <?php echo e(innerStyle('background-image', $video_depoiments->image, null, "url('". $video_depoiments->image . "')")); ?>

">
  <div class="content">
    <h2 class="titulo" style="
      <?php echo e(innerStyle('font-size', $video_depoiments->title_length, null, $video_depoiments->title_length . 'px')); ?>

    "><?php echo e($video_depoiments->title); ?></h2>
    <p class="subtitulo" style="
      <?php echo e(innerStyle('font-size', $video_depoiments->subtitle_length, null, $video_depoiments->subtitle_length . 'px')); ?>

    "><?php echo e($video_depoiments->substitle); ?></p>
    <div class="wrapper-depoiments depoiment-filled">
      <div class="container-depoiments" id="container-depoiments">
        <?php $__currentLoopData = $video_depoiments->depoiments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depoiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!in_array($depoiment->link,['#',''])): ?>
            <div
              class="container-depoiment-item"
              style="<?php echo e(innerStyle('background-image', $depoiment->wallpaper, null, "url('".$depoiment->wallpaper."')")); ?>"
            >
              <button
                type="button"
                class="btn botao"
                style="<?php echo e(innerStyle('background', $video_depoiments->button->color).' '.innerStyle('color', $video_depoiments->button->background)); ?>"
                onclick="$(this).hide('slow').next().attr('src','<?php echo e($depoiment->link); ?>').show('slow');"
              ><?php echo $__env->make('utils.icons.play', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
              <iframe
                src=""
                style="display: none;"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen=""
              ></iframe>
            </div>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <button
        type="button"
        class="btn btn-left botao"
        style="<?php echo e(innerStyle('color', $video_depoiments->button->color).' '.innerStyle('background', $video_depoiments->button->background)); ?>"
        onclick="handleScrollNextOrPrevItem(false, 'container-depoiments', (15 + (2 * .6)) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
      <button
        type="button"
        class="btn btn-right botao"
        style="<?php echo e(innerStyle('color', $video_depoiments->button->color).' '.innerStyle('background', $video_depoiments->button->background)); ?>"
        onclick="handleScrollNextOrPrevItem(true, 'container-depoiments', (15 + (2 * .6)) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
    </div>
    <a
      href="<?php echo e($video_depoiments->button->link); ?>"
      target="_blank"
      class="botao btn btn-primary btn-uppercase"
      style="
        <?php echo e($video_depoiments->button->background ? 'background: '.$video_depoiments->button->background.';' : ''); ?>

        <?php echo e($video_depoiments->button->color ? 'color: '.$video_depoiments->button->color.';' : ''); ?>

      "
    ><?php echo e($video_depoiments->button->text); ?></a>
  </div>
  <?php if(isset($video_depoiments->overlay) && $video_depoiments->overlay): ?>
    <div class="overlay" style="background: <?php echo e($video_depoiments->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/video_depoiments.blade.php ENDPATH**/ ?>