<section id="section_list">
  <div class="content" style="background: <?php echo e($section_list->background); ?>">
    <div>
      <div>
        <h2 class="titulo" style="<?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>">
        <?php echo e($section_list->title); ?>

        </h2>
        <ul style="<?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>">
          <?php $__currentLoopData = $section_list->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <p style="<?php echo e($section_list->text_color ? 'color: '.$section_list->text_color.';' : ''); ?>">
                <?php echo e($item->item); ?>

              </p>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <a
          href="<?php echo e($section_list->button->link); ?>"
          class="botao btn btn-primary btn-uppercase"
          target="_blank"
          style="
            <?php echo e($section_list->button->background ? 'background: '.$section_list->button->background.';' : ''); ?>

            <?php echo e($section_list->button->color ? 'color: '.$section_list->button->color.';' : ''); ?>

          "
        ><?php echo e($section_list->button->text); ?></a>
      </div>
    </div>
    <img src="<?php echo e($section_list->image); ?>" alt="<?php echo e($section_list->title); ?>"/>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/section_list.blade.php ENDPATH**/ ?>