<section id="testimonial" style="
  <?php echo e(innerStyle('background-image', $testimonial->image, null, "url('". $testimonial->image . "')")); ?>

">
  <div class="content" style="background: <?php echo e($testimonial->background); ?>">
    <div class="container-clients">
      <?php $__currentLoopData = $testimonial->clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="client">
          <div class="content-image">
            <img src="<?php echo e($client->image); ?>" alt="<?php echo e($client->name); ?>"/>
            <img src="<?php echo e(asset('images/iconedepoimento.png')); ?>" alt="icone" class="icon"/>
          </div>
          <strong style="
            <?php echo e($testimonial->text_color ? 'color: '.$testimonial->text_color.';' : ''); ?>

            <?php echo e(innerStyle('font-size', $testimonial->title_length, null, $testimonial->title_length . 'px')); ?>

          "><?php echo e($client->name); ?>, <span><?php echo e($client->address); ?></span></strong>
          <p class="texto" style="
            <?php echo e($testimonial->text_color ? 'color: '.$testimonial->text_color.';' : ''); ?>

            <?php echo e(innerStyle('font-size', $testimonial->description_length, null, $testimonial->description_length . 'px')); ?>

          "><?php echo e($client->description); ?></p>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="group-buttons">
      <a
        href="<?php echo e($testimonial->button->link); ?>"
        target="_blank"
        class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($testimonial->button->background ? 'background: '.$testimonial->button->background.';' : ''); ?>

          <?php echo e($testimonial->button->color ? 'color: '.$testimonial->button->color.';' : ''); ?>

        "
      ><?php echo e($testimonial->button->text); ?></a>
    </div>
  </div>
  <?php if(isset($testimonial->overlay) && $testimonial->overlay): ?>
    <div class="overlay" style="background: <?php echo e($testimonial->overlay); ?>"></div>
  <?php endif; ?>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/testimonial.blade.php ENDPATH**/ ?>