<div id="accept-cookies" style="display: none;">
  <div class="content">
      <div class="title-card">
        <strong>Esse site usa cookies</strong>
        <?php echo $__env->make('utils.icons.cookies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <p>Nós armazenamos dados temporariamente para melhorar a sua experiencia de navegação e recomendar conteúdo do seu enteresse. Ao utilizar este site você concorda com tal monitoramento.</p>
      <a href="<?php echo e(route('privacy.policy')); ?>" target="_blank">Politica de Privacidade</a>
      <button
        type="button"
        onclick="handleAcceptCookies()"
        class="btn btn-primary"
      >OK</button>
  </div>
</div>
<script>
  $(function(){
    let statCookies = localStorage.getItem("@cms:accepted_cookies");
    if (!statCookies || statCookies !== 'accepted') $('#accept-cookies').show('slow');
  });

  function handleAcceptCookies() {
    localStorage.setItem('@cms:accepted_cookies', 'accepted');
    $('#accept-cookies').hide('slow');
  }
</script><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/layout/cookies.blade.php ENDPATH**/ ?>