<section id="banner" style="
  <?php echo e(innerStyle('background-image', $banner->image, null, "url('". $banner->image . "')")); ?>

">
  <div class="content">
    <div>
      <hgroup>
        <strong class="subtitulo" style="
          <?php echo e($banner->caption->color ? 'color: '.$banner->caption->color.';' : ''); ?>

          <?php echo e(innerStyle('font-size', $banner->caption->length, null, $banner->caption->length . 'px')); ?>

        "><?php echo e($banner->caption->text); ?></strong>
        <h1 class="titulo" style="
          <?php echo e($banner->title->color ? 'color: '.$banner->title->color.';' : ''); ?>

          <?php echo e(innerStyle('font-size', $banner->title->length, null, $banner->title->length . 'px')); ?>

        "><?php echo e($banner->title->text); ?></h1>
      </hgroup>
      <p class="texto description" style="
        <?php echo e($banner->description->color ? 'color: '.$banner->description->color.';' : ''); ?>

        <?php echo e(innerStyle('font-size', $banner->description->length, null, $banner->description->length . 'px')); ?>

      "><?php echo $banner->description->text; ?></p>
    </div>
  </div>
  <div class="overlay" style="background: <?php echo e($banner->overlay); ?>"></div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php_slider\views/sections/banner/only_text.blade.php ENDPATH**/ ?>