<section id="cms_gallery"
  style="<?php echo e(innerStyle('background', $cms_gallery->background)); ?>"
>
  <div class="content" id="galeria" style="
    <?php echo e(innerStyle('color', $cms_gallery->text_color)); ?>

  ">
    <h2><?php echo e($cms_gallery->title); ?></h2>
    <p><?php echo e($cms_gallery->subtitle); ?></p>
    <div class="wrapper-gallery">
      <div id="container-gallery">
        <p class="text-loading texto">Carregando Galeria...</p>
      </div>
      <button
        type="button"
        class="btn btn-left botao"
        style="<?php echo e(innerStyle('color', $cms_gallery->button->color, '#fff').' '.innerStyle('background', $cms_gallery->button->background, '#5e72e4')); ?>"
        onclick="handleScrollNextOrPrevItem(false, 'container-gallery', (15 + (2 * .4)) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
      <button
        type="button"
        class="btn btn-right botao"
        style="<?php echo e(innerStyle('color', $cms_gallery->button->color, '#fff').' '.innerStyle('background', $cms_gallery->button->background, '#5e72e4')); ?>"
        onclick="handleScrollNextOrPrevItem(true, 'container-gallery', (15 + (2 * .4)) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/cms_gallery.blade.php ENDPATH**/ ?>