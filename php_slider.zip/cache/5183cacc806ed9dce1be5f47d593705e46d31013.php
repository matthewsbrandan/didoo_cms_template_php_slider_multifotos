<section id="cms_blog" style="<?php echo e(innerStyle('color', $cms_blog->background)); ?>">
  <div class="content" id="blog">
    <h2 class="titulo" style="<?php echo e(innerStyle('color', $cms_blog->text_color)); ?>"><?php echo e($cms_blog->title); ?></h2>
    <div class="wrapper-blog">
      <div id="container-blog" style="<?php echo e(innerStyle('color', $cms_blog->text_color)); ?>">
        <p class="text-loading texto">Carregando Posts...</p>
      </div>
      <button
        type="button"
        class="btn btn-left botao"
        style="<?php echo e(innerStyle('color', $cms_blog->button->color).' '.innerStyle('background', $cms_blog->button->background)); ?>"
        onclick="handleScrollNextOrPrevItem(false, 'container-blog', (15 + 1.6 + .4) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
      <button
        type="button"
        class="btn btn-right botao"
        style="<?php echo e(innerStyle('color', $cms_blog->button->color).' '.innerStyle('background', $cms_blog->button->background)); ?>"
        onclick="handleScrollNextOrPrevItem(true, 'container-blog', (15 + 1.6 + .4) * 16)"
      ><?php echo $__env->make('utils.icons.chevron_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></button>
    </div>
    <div class="group-buttons">
      <a
        href="<?php echo e(route('blog.feed.index')); ?>"
        target="_blank"
        class="botao btn btn-primary btn-uppercase"
        style="
          <?php echo e($cms_blog->button->background ? 'background: '.$cms_blog->button->background.';' : ''); ?>

          <?php echo e($cms_blog->button->color ? 'color: '.$cms_blog->button->color.';' : ''); ?>

        "
      >Ver Blog</a>
    </div>
  </div>
</section><?php /**PATH C:\xampp\htdocs\codewriters\templates_didoo\php\views/sections/cms_blog.blade.php ENDPATH**/ ?>